/**
 * Vercel Serverless Function - Discord Username Collector
 * 
 * This function acts as a secure proxy between the client-side modal
 * and the Discord Webhook API.
 */

const axios = require('axios');

// Rate limiting store (in-memory, resets on cold start)
const requestStore = new Map();

const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const RATE_LIMIT_MAX = 10; // 10 requests per window

/**
 * Simple rate limiter for serverless environment
 */
function checkRateLimit(ip) {
  const now = Date.now();
  const userRequests = requestStore.get(ip) || [];
  
  // Filter out old requests outside the window
  const recentRequests = userRequests.filter(timestamp => now - timestamp < RATE_LIMIT_WINDOW_MS);
  
  if (recentRequests.length >= RATE_LIMIT_MAX) {
    return { allowed: false };
  }
  
  recentRequests.push(now);
  requestStore.set(ip, recentRequests);
  return { allowed: true };
}

/**
 * Sanitizes and validates the username input
 * Discord username format: 2-32 chars, lowercase alphanumeric, underscores, periods
 */
function validateUsername(username) {
  if (!username || typeof username !== 'string') {
    return { valid: false, error: 'Username must be a non-empty string' };
  }

  const sanitized = username.trim().toLowerCase();

  if (sanitized.length < 2 || sanitized.length > 32) {
    return { valid: false, error: 'Username must be between 2 and 32 characters' };
  }

  // Discord username format: lowercase alphanumeric, underscores, periods only
  const usernameRegex = /^[a-z0-9._]+$/;
  if (!usernameRegex.test(sanitized)) {
    return { valid: false, error: 'Username can only contain lowercase letters, numbers, underscores, and periods' };
  }

  return { valid: true, sanitized: sanitized };
}

/**
 * Validates Discord ID format (17-20 digits)
 */
function validateDiscordId(userId) {
  if (!userId || typeof userId !== 'string') {
    return { valid: true, sanitized: null }; // Optional field
  }

  const trimmed = userId.trim();

  if (trimmed.length === 0) {
    return { valid: true, sanitized: null }; // Empty is OK (optional)
  }

  // Discord IDs are 17-20 digit numbers (snowflakes)
  const discordIdRegex = /^\d{17,20}$/;
  if (!discordIdRegex.test(trimmed)) {
    return { valid: false, error: 'Invalid Discord ID format. Must be 17-20 digits.' };
  }

  return { valid: true, sanitized: trimmed };
}

/**
 * Fetch Discord user info from ID using Discord API
 */
async function getDiscordUserFromId(userId, botToken) {
  if (!userId || !botToken) return null;

  try {
    const response = await axios.get(`https://discord.com/api/v10/users/${userId}`, {
      headers: {
        'Authorization': `Bot ${botToken}`
      },
      timeout: 5000,
      validateStatus: (status) => status >= 200 && status < 300
    });

    const user = response.data;
    
    // Build avatar URL
    const avatarUrl = user.avatar 
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.${user.avatar.startsWith('a_') ? 'gif' : 'png'}?size=256`
      : `https://cdn.discordapp.com/embed/avatars/${parseInt(user.discriminator) % 5}.png`;

    // Calculate account creation date
    const snowflakeTimestamp = (BigInt(user.id) >> 22n) + 1420070400000n;
    const createdAt = new Date(Number(snowflakeTimestamp)).toISOString();

    // Get public flags/badges
    const badges = [];
    const flags = user.public_flags || 0;
    if (flags & 1) badges.push('Staff');
    if (flags & 2) badges.push('Partner');
    if (flags & 4) badges.push('HypeSquad Events');
    if (flags & 8) badges.push('Bug Hunter Level 1');
    if (flags & 64) badges.push('HypeSquad House Bravery');
    if (flags & 128) badges.push('HypeSquad House Brilliance');
    if (flags & 256) badges.push('HypeSquad House Balance');
    if (flags & 512) badges.push('Early Supporter');
    if (flags & 16384) badges.push('Bug Hunter Level 2');
    if (flags & 131072) badges.push('Verified Bot Developer');
    if (flags & 262144) badges.push('Active Developer');

    return {
      username: user.username,
      discriminator: user.discriminator,
      global_name: user.global_name,
      id: user.id,
      display: user.global_name || `${user.username}#${user.discriminator}`,
      avatar: avatarUrl,
      bot: user.bot || false,
      badges: badges,
      createdAt: createdAt,
      banner: user.banner ? `https://cdn.discordapp.com/banners/${user.id}/${user.banner}.png?size=512` : null
    };
  } catch (error) {
    console.error('Discord ID lookup failed:', error.message);
    return null;
  }
}

/**
 * Extract client info from request headers
 */
function extractClientInfo(req) {
  const headers = req.headers || {};
  return {
    ip: headers['x-forwarded-for']?.split(',')[0]?.trim() || headers['x-real-ip'] || 'Unknown',
    userAgent: headers['user-agent'] || 'Unknown',
    origin: headers['origin'] || headers['referer'] || 'Unknown'
  };
}

/**
 * Fetch detailed IP geolocation data with VPN/Tor detection
 */
async function getIPLocation(ip) {
  if (!ip || ip === 'Unknown') return null;

  try {
    // Use ipapi.co for IP geolocation with VPN/Tor detection
    const response = await axios.get(`https://ipapi.co/${ip}/json/`, {
      timeout: 5000,
      validateStatus: (status) => status >= 200 && status < 300
    });

    const data = response.data;
    return {
      city: data.city || 'Unknown',
      region: data.region || 'Unknown',
      country: data.country_name || 'Unknown',
      postal: data.postal || 'Unknown',
      latitude: data.latitude || 'Unknown',
      longitude: data.longitude || 'Unknown',
      timezone: data.timezone || 'Unknown',
      isp: data.org || data.asn || 'Unknown',
      asn: data.asn || 'Unknown',
      vpn: data.vpn || false,
      tor: data.tor || false,
      proxy: data.proxy || false,
      hosting: data.hosting || false
    };
  } catch (error) {
    console.error('IP lookup failed:', error.message);
    return null;
  }
}

/**
 * CORS headers helper
 */
function getCorsHeaders(origin) {
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').filter(Boolean);
  const allowOrigin = allowedOrigins.length > 0 
    ? (allowedOrigins.includes(origin) ? origin : allowedOrigins[0])
    : '*';
  
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400'
  };
}

/**
 * Main handler for Vercel serverless function
 */
module.exports = async function handler(req, res) {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    const origin = req.headers?.origin;
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(200).end();
  }

  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: 'Method not allowed'
    });
  }

  const origin = req.headers?.origin;
  const corsHeaders = getCorsHeaders(origin);
  Object.entries(corsHeaders).forEach(([key, value]) => {
    res.setHeader(key, value);
  });

  // Rate limiting
  const clientIp = extractClientInfo(req).ip;
  const rateLimit = checkRateLimit(clientIp);
  
  if (!rateLimit.allowed) {
    return res.status(429).json({
      success: false,
      error: 'Too many requests. Please try again later.'
    });
  }

  // Validate webhook URL
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
  if (!webhookUrl) {
    console.error('ERROR: DISCORD_WEBHOOK_URL not configured');
    return res.status(500).json({
      success: false,
      error: 'Server configuration error'
    });
  }

  // Parse and validate input
  let body;
  try {
    body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  } catch (e) {
    return res.status(400).json({
      success: false,
      error: 'Invalid JSON payload'
    });
  }

  const { userId } = body || {};

  // Validate Discord ID (now required)
  if (!userId || typeof userId !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'Discord ID is required'
    });
  }

  const userIdValidation = validateDiscordId(userId);
  if (!userIdValidation.valid) {
    return res.status(400).json({
      success: false,
      error: userIdValidation.error
    });
  }

  const sanitizedUserId = userIdValidation.sanitized;
  const clientInfo = extractClientInfo(req);
  const { validatedUser } = body || {};

  console.log(`Discord ID submitted: ${sanitizedUserId} from IP: ${clientInfo.ip}`);

  // Use pre-validated user info if provided, otherwise fetch from Discord API
  let discordUserInfo = null;
  if (validatedUser) {
    // Use the pre-validated user info from the frontend
    discordUserInfo = validatedUser;
    console.log(`Discord ID using pre-validated info: ${discordUserInfo.display}`);
  } else if (process.env.DISCORD_BOT_TOKEN) {
    // Fallback to fetching from Discord API if no pre-validated info
    discordUserInfo = await getDiscordUserFromId(sanitizedUserId, process.env.DISCORD_BOT_TOKEN);
    if (discordUserInfo) {
      console.log(`Discord ID resolved: ${discordUserInfo.display}`);
    }
  }

  // Fetch detailed IP location data
  const ipLocation = await getIPLocation(clientInfo.ip);

  // Construct Discord embed payload with detailed info
  const discordPayload = {
    embeds: [{
      title: '✅ User Verified',
      description: discordUserInfo 
        ? `A Discord user has verified themselves through the website.`
        : 'A user has verified with their Discord ID.',
      color: 0x5865F2,
      thumbnail: discordUserInfo ? { url: discordUserInfo.avatar } : undefined,
      fields: [
        {
          name: '👤 User',
          value: discordUserInfo
            ? `**${discordUserInfo.display}**\n**Username:** \`${discordUserInfo.username}${discordUserInfo.discriminator !== '0' ? '#' + discordUserInfo.discriminator : ''}\`\n**ID:** \`${sanitizedUserId}\``
            : `\`${sanitizedUserId}\`\n*(Lookup failed - no bot token)*`,
          inline: false
        },
        {
          name: '🤖 Bot Account',
          value: discordUserInfo ? (discordUserInfo.bot ? '✅ Yes' : '❌ No') : 'Unknown',
          inline: true
        },
        {
          name: '🏷️ Badges',
          value: discordUserInfo && discordUserInfo.badges && discordUserInfo.badges.length > 0
            ? discordUserInfo.badges.map(b => `• ${b}`).join('\n')
            : 'None',
          inline: true
        },
        {
          name: '📅 Account Created',
          value: discordUserInfo && discordUserInfo.createdAt
            ? `<t:${Math.floor(new Date(discordUserInfo.createdAt).getTime() / 1000)}:R>`
            : 'Unknown',
          inline: true
        },
        {
          name: '🖼️ Banner',
          value: discordUserInfo && discordUserInfo.banner ? `[View Banner](${discordUserInfo.banner})` : 'None',
          inline: true
        },
        {
          name: '🔒 Security',
          value: (() => {
            const flags = [];
            if (ipLocation?.vpn) flags.push('⚠️ **VPN**');
            if (ipLocation?.tor) flags.push('⚠️ **Tor**');
            if (ipLocation?.proxy) flags.push('⚠️ Proxy');
            if (ipLocation?.hosting) flags.push('🖥️ Hosting');
            if (flags.length === 0) flags.push('✅ Clean IP');
            return flags.join('\n');
          })(),
          inline: false
        },
        {
          name: '🌐 IP Address',
          value: `\`${clientInfo.ip}\``,
          inline: true
        },
        {
          name: '📍 Location',
          value: ipLocation
            ? `${ipLocation.city}, ${ipLocation.region}`
            : 'Unknown',
          inline: true
        },
        {
          name: '🌍 Country',
          value: ipLocation ? `${ipLocation.country}` : 'Unknown',
          inline: true
        },
        {
          name: '🏢 ISP',
          value: ipLocation ? `\`${ipLocation.isp}\`` : 'Unknown',
          inline: true
        },
        {
          name: '🕐 Timezone',
          value: ipLocation ? `\`${ipLocation.timezone}\`` : 'Unknown',
          inline: true
        },
        {
          name: '📦 User Agent',
          value: `\`\`\`${clientInfo.userAgent.substring(0, 150)}\`\`\``,
          inline: false
        }
      ],
      footer: {
        text: `Verification System • ${discordUserInfo && discordUserInfo.bot ? 'Bot Account Detected' : 'Human Verification'}`,
        icon_url: 'https://cdn.discordapp.com/embed/avatars/0.png'
      },
      timestamp: new Date().toISOString()
    }],
    username: 'Verification Bot',
    avatar_url: 'https://cdn.discordapp.com/embed/avatars/0.png'
  };

  // Send to Discord webhook
  try {
    console.log('Sending to Discord webhook:', JSON.stringify(discordPayload, null, 2).substring(0, 500));
    
    const response = await axios.post(webhookUrl, discordPayload, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10000,
      validateStatus: (status) => status >= 200 && status < 300
    });

    console.log('Discord webhook response:', response.status);

    if (response.status >= 200 && response.status < 300) {
      return res.status(200).json({
        success: true,
        message: 'Username submitted successfully'
      });
    } else {
      console.error('Discord API returned status:', response.status, response.data);
      throw new Error(`Discord API returned status ${response.status}`);
    }
  } catch (error) {
    console.error('Error forwarding to Discord:', error.message);

    if (error.response) {
      console.error('Discord API Error:', JSON.stringify(error.response.data, null, 2));
      return res.status(502).json({
        success: false,
        error: `Failed to forward to Discord: ${error.response.data.message || error.message}`
      });
    }

    if (error.code === 'ECONNABORTED') {
      return res.status(504).json({
        success: false,
        error: 'Request timed out'
      });
    }

    return res.status(500).json({
      success: false,
      error: 'An unexpected error occurred'
    });
  }
};
